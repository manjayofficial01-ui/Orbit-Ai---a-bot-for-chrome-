#!/usr/bin/env python3
"""Patch an extracted Orbit AI folder; no third-party packages required."""
from pathlib import Path
import json, shutil, sys

def install(argument):
    target=Path(argument).expanduser().resolve()
    if (target/'dist'/'manifest.json').is_file():target=target/'dist'
    if not (target/'manifest.json').is_file():raise SystemExit('Choose the extracted orbit-ai or orbit-ai/dist folder.')
    app=target/'app.js';manifest_path=target/'manifest.json'
    source=app.read_text(encoding='utf-8')
    start=source.find("$('page').onclick=")
    end=source.find("$('file').onclick=",start)
    if start<0 or end<0:raise SystemExit('Unsupported app.js layout. No files changed. Upload your original ZIP for an integrated fix.')
    backup=target.parent/'backup-before-page-fix'
    backup.mkdir(exist_ok=True)
    for name in ['manifest.json','app.js']:
        if not (backup/name).exists():shutil.copy2(target/name,backup/name)
    patched=source[:start]+"$('page').textContent='Page tools';\n$('page').onclick=safe(()=>openPageTools(showPreview));\n"+source[end:]
    if "import {openPageTools}" not in patched:patched="import {openPageTools} from './page-access.js';\n"+patched
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    manifest['version']='1.0.1'
    permissions=manifest.setdefault('permissions',[])
    for name in ['tabs','activeTab','scripting']:
        if name not in permissions:permissions.append(name)
    optional=manifest.setdefault('optional_host_permissions',[])
    for pattern in ['https://*/*','http://*/*']:
        if pattern not in optional:optional.append(pattern)
    shutil.copy2(Path(__file__).parent/'page-access.js',target/'page-access.js')
    app.write_text(patched,encoding='utf-8')
    manifest_path.write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    src=target.parent/'src'
    if src.is_dir():
        (src/'app.js').write_text(patched,encoding='utf-8')
        shutil.copy2(target/'page-access.js',src/'page-access.js')
    print('Patched:',target)
    print('Backup:',backup)
    print('Reload Orbit at chrome://extensions. Close old Orbit panels/tabs and reopen. Use Page tools.')

if __name__=='__main__':
    if len(sys.argv)!=2:raise SystemExit('Usage: python apply_fix.py "/path/to/orbit-ai"')
    install(sys.argv[1])
