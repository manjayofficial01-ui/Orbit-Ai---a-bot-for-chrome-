import test from 'node:test';
import assert from 'node:assert/strict';
import {pageOrigin,targetTabs,writeField} from './page-access.js';
test('HTTPS origin pattern ignores path and port',()=>assert.equal(pageOrigin('https://example.com:8443/a?q=x'),'https://example.com/*'));
test('ordinary HTTP page supported',()=>assert.equal(pageOrigin('http://example.com/a'),'http://example.com/*'));
test('restricted URL schemes rejected',()=>{for(const s of ['chrome://settings','chrome-extension://abc/index.html','file:///tmp/test','about:blank','javascript:alert(1)'])assert.throws(()=>pageOrigin(s));});
test('both Chrome Web Store domains blocked',()=>{for(const s of ['https://chromewebstore.google.com/detail/a','https://chrome.google.com/webstore/detail/a'])assert.throws(()=>pageOrigin(s));});
test('tab picker excludes restricted tabs and orders by recent access',()=>{const tabs=[{id:1,url:'chrome://settings',lastAccessed:50},{id:2,url:'https://a.example',lastAccessed:1},{id:3,url:'http://b.example',lastAccessed:10},{id:4}];assert.deepEqual(targetTabs(tabs,'chrome-extension://id/index.html').map(t=>t.id),[3,2]);});
function setup(value='old'){
 globalThis.location={href:'https://example.com/page'};
 const el={isConnected:true,disabled:false,readOnly:false,tagName:'TEXTAREA',isContentEditable:false,autocomplete:'',name:'',id:'',value,getClientRects:()=>[{}],getAttribute:()=>null,focus(){},dispatchEvent(){}};
 class TextArea{}Object.defineProperty(TextArea.prototype,'value',{set(v){this.value=v;}});globalThis.HTMLTextAreaElement=TextArea;
 globalThis.__orbitPageEdit={token:'scan',url:location.href,map:new Map([['0',{el,value}]])};return el;
}
test('successful write uses setter and invalidates handle',()=>{const el=setup();assert.deepEqual(writeField('scan','0','new',location.href),{ok:true});assert.equal(el.value,'new');assert.equal(__orbitPageEdit.map.has('0'),false);});
test('stale scan token blocked',()=>{setup();assert.match(writeField('wrong','0','new',location.href).error,/changed|scan/);});
test('navigation blocked',()=>{setup();location.href='https://example.com/other';assert.ok(writeField('scan','0','new','https://example.com/page').error);});
test('concurrent user edit blocked',()=>{const el=setup();el.value='user edit';assert.match(writeField('scan','0','new',location.href).error,/Field changed/);assert.equal(el.value,'user edit');});
test('sensitive field blocked',()=>{const el=setup();el.name='api_key';assert.match(writeField('scan','0','secret',location.href).error,/Sensitive/);});
test('detached, readonly and oversized writes blocked',()=>{let el=setup();el.isConnected=false;assert.ok(writeField('scan','0','new',location.href).error);el=setup();el.readOnly=true;assert.ok(writeField('scan','0','new',location.href).error);setup();assert.ok(writeField('scan','0','x'.repeat(50001),location.href).error);});
