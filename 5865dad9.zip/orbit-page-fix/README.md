# Orbit AI 1.0.1 — page access and reviewed writing patch

This ZIP is a patch for the Orbit extension generated earlier. It is NOT a complete standalone extension. The original ZIP was not available in the current execution session. The installer preserves the existing chat/provider implementation and backs up app.js and manifest.json before changing them.

## Why the earlier Page button failed
The previous implementation called scripting.executeScript directly, relying only on temporary activeTab access. Merely clicking a button inside an already-open side panel does not invoke the extension toolbar and grant activeTab to a new page. A full workspace tab could also select itself as the active tab. Provider API host grants do not automatically grant access to unrelated webpages. The prior build did not implement writing at all.

Chrome references:
- https://developer.chrome.com/docs/extensions/develop/concepts/activeTab
- https://developer.chrome.com/docs/extensions/reference/api/scripting

## Apply the fix
1. Extract this patch ZIP.
2. Close all Orbit panels and workspace tabs. Export important chats as a precaution.
3. Open a terminal in the extracted patch folder.
4. Run with Python 3 (no third-party modules):

       python apply_fix.py "/path/to/your/extracted/orbit-ai"

   Windows example:

       py apply_fix.py "C:\Users\YourName\Downloads\orbit-ai"

   macOS/Linux example:

       python3 apply_fix.py "$HOME/Downloads/orbit-ai"

   You may pass either the orbit-ai folder or its dist folder. Do not pass a ZIP file.
5. Go to chrome://extensions, find Orbit and click Reload. Review/accept updated permissions if Chrome asks. Session API keys may be forgotten on reload; re-enter them in Settings if needed.
6. Open a normal webpage, open Orbit and click Page tools.
7. Confirm the target webpage in the dropdown (important in full-tab mode).
8. Click Grant access to this site and approve Chrome's prompt.
9. Click Read page & scan fields. Review the text before attaching it to chat.

## Write text into the page
1. Grant access and read/scan the intended webpage.
2. Select the intended text input, textarea or ordinary contenteditable field in Page tools.
3. Paste/type the exact replacement text. It REPLACES the entire field.
4. Click Review & write field. Confirm the named field, site and exact replacement.
5. Inspect the result on the webpage yourself. No submit button is clicked.

Website input/change handlers can autosave or send text as soon as it is inserted. The confirmation warns about this. This is a manual reviewed write tool, not an autonomous AI browser agent. AI output cannot invoke writes; paste the answer you want to insert.

Writes are pinned to the scanned document ID, scan token, field handle, URL and original field value. Navigation, detached/readonly fields, changed values, invalidated scans and obvious sensitive-field identifiers block writing. Password/payment/OTP-like fields are excluded; heuristics do not detect every sensitive field, so inspect the target carefully. Each successful field handle is invalidated; scan again for another write.

## Permission changes
- Adds tabs permission to show target titles/URLs reliably, even before a page host grant. This exposes tab metadata to the extension; it does not itself grant DOM access. Tab lists are not sent to an AI provider.
- Adds optional HTTP site patterns alongside existing optional HTTPS patterns so normal HTTP webpages can be selected too. It does NOT automatically grant all sites.
- Requests only the selected scheme/hostname on the Grant access button. Host patterns cover all paths/ports for that host; the permission is not per tab or API path.
- Revoke this site removes the persistent host grant. A temporary activeTab grant may still last until navigation or tab close.
- Provider-host permissions and webpage permissions use the same Chrome host permission system. Revoking a site that is also your API provider can therefore affect that connection too.
- The original Delete all local data control also revokes granted optional hosts.

## Supported and unsupported pages
Supported: ordinary HTTP/HTTPS top-frame webpages where Chrome permits injection. Page reading captures selection if present, otherwise visible page text up to 24,000 characters. Editable field scan is limited to 100 fields, and replacement text to 50,000 characters.

Not bypassed: chrome:// pages, the Chrome Web Store, other extension pages, enterprise-blocked sites, built-in PDF viewers and browser security restrictions. Cross-origin iframes and shadow-DOM editors are not traversed. Complex rich-text editors may reject changes or lose formatting. Closed shadow roots and inaccessible frames require separate site-specific support.

## Validation and rollback
- 11 Node tests passed for URL rules, target ordering and write safety checks (mock DOM).
- JavaScript syntax check passed.
- Installer fixture test passed, including reapplication without duplicate import and backup preservation.
- No native Chrome executable or real website automation was available, so native permission prompts, page DOM operations and rich-editor compatibility remain unverified. Tests do not claim otherwise.

Run optional tests with Node:

    node --test page-access.test.mjs

Rollback: restore app.js and manifest.json from the backup-before-page-fix folder next to dist, remove dist/page-access.js, then reload Orbit. Already approved optional site grants should be reviewed in Chrome's extension site-access settings.

If the installer reports an unsupported app.js layout, it does not modify files. Upload the actual installed extension ZIP for an exact integrated patch.
